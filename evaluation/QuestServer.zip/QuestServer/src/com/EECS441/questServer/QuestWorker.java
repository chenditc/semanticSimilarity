/*
 * Copyright 2012 Amazon Technologies, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *    http://aws.amazon.com/apache2.0
 *
 * This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
 * OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and
 * limitations under the License.
 */
package com.EECS441.questServer;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

import com.EECS441.questServer.AWSResources;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.GetQueueUrlRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.util.json.JSONObject;


/**
 * The quest worker's job is to take work from SQS, look up the details in
 * SimpleDB, then return the reseult to client.
 * 
 * @author dichen
 */
public class QuestWorker extends Thread {
	private final AmazonSQS sqs;
	private final ScheduledExecutorService executorService;
	private final ClasspathPropertiesFileCredentialsProvider provider = new ClasspathPropertiesFileCredentialsProvider();
	
	/**
	 * initializer, setup:
	 * 1. the credential of AWS.
	 * 2. connection end point.
	 * 
	 */
	public QuestWorker() {
		sqs = new AmazonSQSClient(provider);
		sqs.setEndpoint(AWSResources.SQS_ENDPOINT);
		executorService = new ScheduledThreadPoolExecutor(10);
	}

	/**
	 * Start server, get connection request and call the setupClient.
	 * @param args
	 */
	public static void main(String[] args) {
		QuestWorker questWorker = new QuestWorker();
		
		questWorker.start();
		try {
			questWorker.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// Get the url of connection queue.
		String queueUrl = setupConnectionRequestQueue();
		String registerQueueUrl = setupRegisterRequestQueue();
		// Get connection request from client and setup all the clientAgent.
		while (true) {
			try {
				int maxMessage = 10;
				// Receive client request and setup client.
				ReceiveMessageResult receiveMessage = sqs.receiveMessage(new ReceiveMessageRequest().withMaxNumberOfMessages(maxMessage).withQueueUrl(queueUrl));
				for (Message msg : receiveMessage.getMessages()) {
					// setup the client and delete the connection request from queue.
					setupClient(msg, queueUrl);
					sqs.deleteMessage(new DeleteMessageRequest().withQueueUrl(queueUrl).withReceiptHandle(msg.getReceiptHandle()));
				}
				
				// Receive register request and setup register.
				receiveMessage = sqs.receiveMessage(new ReceiveMessageRequest(registerQueueUrl).withMaxNumberOfMessages(maxMessage));
				for (Message msg : receiveMessage.getMessages()) {
					// setup the client and delete the connection request from queue.
					setupRegister(msg);
					sqs.deleteMessage(new DeleteMessageRequest().withQueueUrl(registerQueueUrl).withReceiptHandle(msg.getReceiptHandle()));
				}
				
				// waiting time for server.
				sleep(500);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			} catch (Exception e) {
				// ignore and retry
			}
		}
	}
	
	/**
	 * Set up the server's initial connection queue.
	 * @return the Url of the connection queue.
	 */
	private String setupConnectionRequestQueue() {
		// server connection queue is used only for initial connection.
		CreateQueueRequest createQueueRequest = new CreateQueueRequest("serverConnection");
		CreateQueueResult createQueueResult = sqs.createQueue(createQueueRequest);
		String queueUrl = createQueueResult.getQueueUrl();
		System.out.println(queueUrl);
		return queueUrl;
	}
	
	/**
	 * Set up the server's register connection queue.
	 * @return the Url of the connection queue.
	 */
	private String setupRegisterRequestQueue() {
		// server connection queue is used only for initial connection.
		CreateQueueRequest createQueueRequest = new CreateQueueRequest("registerConnection");
		CreateQueueResult createQueueResult = sqs.createQueue(createQueueRequest);
		String queueUrl = createQueueResult.getQueueUrl();
		System.out.println(queueUrl);
		return queueUrl;
	}

	/**
	 * setup a client agent to serve the client
	 */
	private void setupClient(final Message msg, final String queueUrl) throws IOException {
		
		// create a new thread to setup the client.
		Runnable processRunnable = new Runnable() {
			
			@Override
			public void run() {				
				// Create a agent to serve the client's request.
				if (msg.getBody() != null){
					ClientAgent clientAgent = new ClientAgent(msg);
					clientAgent.start();
					try {
						clientAgent.join();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}				
			}
		};

		executorService.schedule(processRunnable, 0, TimeUnit.SECONDS);
	}
	
	/**
	 * Setup a register to serve the client.
	 */
	private void setupRegister(final Message msg) throws IOException {
		
		// create a new thread to setup the client.
		Runnable processRunnable = new Runnable() {
			
			@Override
			public void run() {				
				// Create a agent to serve the client's request.
				if (msg.getBody() != null){
					ClientRegister clientRegister = new ClientRegister(msg);
					clientRegister.start();
					try {
						clientRegister.join();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}				
			}
		};

		executorService.schedule(processRunnable, 0, TimeUnit.SECONDS);
	}
	
	
}

