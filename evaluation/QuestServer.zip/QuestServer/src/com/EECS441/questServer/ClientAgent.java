/*
 * Copyright 2012 Amazon Technologies, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *    http://aws.amazon.com/apache2.0
 *
 * This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
 * OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and
 * limitations under the License.
 */
package com.EECS441.questServer;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.impl.Log4JLogger;

import sun.tools.tree.ThisExpression;

import aj.org.objectweb.asm.Attribute;

import com.EECS441.questServer.AWSResources;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.services.simpledb.AmazonSimpleDB;
import com.amazonaws.services.simpledb.AmazonSimpleDBClient;
import com.amazonaws.services.simpledb.model.CreateDomainRequest;
import com.amazonaws.services.simpledb.model.GetAttributesRequest;
import com.amazonaws.services.simpledb.model.GetAttributesResult;
import com.amazonaws.services.simpledb.model.Item;
import com.amazonaws.services.simpledb.model.PutAttributesRequest;
import com.amazonaws.services.simpledb.model.ReplaceableAttribute;
import com.amazonaws.services.simpledb.model.SelectRequest;
import com.amazonaws.services.simpledb.model.SelectResult;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.amazonaws.services.sqs.model.CreateQueueResult;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.GetQueueUrlRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;
import com.amazonaws.util.json.JSONTokener;
import com.sun.mail.imap.protocol.Status;
import com.sun.xml.internal.xsom.impl.scd.Iterators.Map;


/**
 * The quest worker's job is to take work from SQS, look up the details in
 * SimpleDB, then return the reseult to client.
 * 
 * @author dichen
 */
public class ClientAgent extends Thread {
	private final String LoginInfoStorage = "LoginInfo";
	private final String QuestInfoStorage = "QuestInfo";
	private final AmazonSQS sqs;
	private final AmazonSimpleDB simpleDB;
	private final ScheduledExecutorService executorService;
	private final ClasspathPropertiesFileCredentialsProvider provider = new ClasspathPropertiesFileCredentialsProvider();
	private String clientName;
	// The client+Send is the queue where client send stuff
	private String sendQueueUrl;
	// The client+Receive is the queue where client receive stuff
	private String receiveQueueUrl;
	private JSONObject message;
	private String registerProcessId;
	private boolean domainExist = false;
	
	private Logger logger = Logger.getLogger("ClientAgent");
	/**
	 * @param msg: msg.getBody() cannot be null
	 * 
	 * initializer, setup:
	 * 1. the credential of AWS.
	 * 2. connection end point.
	 * 3. TODO: check the credential of this client.
	 * 
	 */
	public ClientAgent(Message msg) {		
		// Setup the sqs
		sqs = new AmazonSQSClient(provider);
		sqs.setEndpoint(AWSResources.SQS_ENDPOINT);
		simpleDB = new AmazonSimpleDBClient(provider);
		registerProcessId = msg.getMessageId();
		try {
			message = new JSONObject(msg.getBody());
			clientName = (String) message.get("userName");
			// create two queues for this client.
			// The client+Send is the queue where client send stuff
			receiveQueueUrl = sqs.createQueue(new CreateQueueRequest(clientName+"Send")).getQueueUrl();
			// The client+Receive is the queue where client receive stuff
			sendQueueUrl = sqs.createQueue(new CreateQueueRequest(clientName+"Receive")).getQueueUrl();
		} catch (JSONException e) {
			message = null;
			e.printStackTrace();
		}
		clearQueue(receiveQueueUrl);
		clearQueue(sendQueueUrl);
		DBCheck();
		executorService = new ScheduledThreadPoolExecutor(10);
	}

	@Override
	public void run() {	
		processRequest();
	}

	/**
	 * Processes the message given
	 */
	private void processRequest(){
		if (message == null){
			return;
		}
		try {
			String requestType = (String) message.get("requestType");
			// If the request a login request.
			if (requestType.equals("login")){
				// verify the user's credential, then send the response.
				String status = verifyUser();
				logger.info("The login status for user:"+clientName+" is:"+status);
				java.util.Map<String,String> jsonMap = new HashMap<String,String>();
				jsonMap.put("loginStatus", status);
				// send the response to unique login queue.
				sendQueueUrl = sqs.createQueue(new CreateQueueRequest(registerProcessId+"Receive")).getQueueUrl();
				sqs.sendMessage(new SendMessageRequest(sendQueueUrl, new JSONObject(jsonMap).toString()));;
			}
			else if(requestType.equals("newQuest")){
				String status = postNewQuest();
				logger.info("the new quest post status is:"+status);
				java.util.Map<String,String> jsonMap = new HashMap<String,String>();
				jsonMap.put("questStatus", status);
				sqs.sendMessage(new SendMessageRequest(sendQueueUrl, new JSONObject(jsonMap).toString()));;
			}
			else if (requestType.equals("fetchQuest")){
				logger.info("get a fetch request");
				String result = fetchTopQuest();
				java.util.Map<String,String> jsonMap = new HashMap<String,String>();
				jsonMap.put("questStatus", "fetchSuccess");
				jsonMap.put("quests", result);
				sqs.sendMessage(new SendMessageRequest(sendQueueUrl, new JSONObject(jsonMap).toString()));;
			}
		} catch (JSONException e) {
			System.out.println("Invalid request");
			return;
		}
	}

	/**
	 * Performs the buffered image overlay process with a timeout
	 */
	/*
	private BufferedImage overlayImage(MemeCreationJob job, BufferedImage image)
			throws IOException, InterruptedException {

		// A timer to interrupt us after a timeout
		final Thread thread = Thread.currentThread();
		Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				thread.interrupt();
			}
		}, 10000);

		BufferedImage overlay = ImageOverlay.overlay(image,
				job.getTopCaption(), job.getBottomCaption());
		return overlay;
	}
	*/
	
	private String tryingGetMessageForTime(int time) {
		int timeout = 0;
		while(timeout < 500*time*2){
			try {
				ReceiveMessageResult receiveMessage = sqs.receiveMessage(new ReceiveMessageRequest(receiveQueueUrl));
				if (receiveMessage.getMessages().size() != 0){
					Message msg = receiveMessage.getMessages().get(0);
					sqs.deleteMessage(new DeleteMessageRequest().withQueueUrl(receiveQueueUrl).withReceiptHandle(msg.getReceiptHandle()));
					return msg.getBody();
				}
				sleep(500);
				timeout+=500;
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return null;
			} catch (Exception e) {
				// ignore and retry
			}
		}
		return null;
	}
	/**
	 * 
	 * @return "questSuccess" 		if the quest post successfully.
	 * 		   "questFail"			if the quest post fail.
	 */
	private String postNewQuest() {
		String userName= null;
		String description = null;
		try {
			userName = message.getString("userName");
			description = message.getString("questDescription");
		} catch (JSONException e) {
			return "questFail";
		}
		
		List<ReplaceableAttribute> attributeList = new ArrayList<ReplaceableAttribute>();
		attributeList.add(new ReplaceableAttribute("questDescription", description, true));
		attributeList.add(new ReplaceableAttribute("UserName", userName, true));
		// Use a UUID as the quest Id.
		String questId = UUID.randomUUID().toString();
		attributeList.add(new ReplaceableAttribute("QuestId", questId ,true));
		PutAttributesRequest insertRequest = new PutAttributesRequest(QuestInfoStorage, questId, attributeList);
		try {
			simpleDB.putAttributes(insertRequest);
		} catch (Exception e) {
			return "questFail";
		}
	
		return "questSuccess";
	}
	
	/**
	 * 
	 * @return "loginFail" 		if the user does not exist, or the password is wrong, or the request is not valid.
	 * 		   "loginSuccess"	if the user name and password matches each other.
	 */
	private String verifyUser() {
		String userName= null;
		String password = null;
		try {
			userName = message.getString("userName");
			password = message.getString("password");
		} catch (JSONException e) {
			return "loginFail";
		}
		GetAttributesResult result = simpleDB.getAttributes(new GetAttributesRequest(LoginInfoStorage, userName));
		if (result.getAttributes().size() == 0){
			System.out.println("There's no this user");
			return "loginFail";
		}
		else{
			List<com.amazonaws.services.simpledb.model.Attribute> attributes = result.getAttributes();
			for (com.amazonaws.services.simpledb.model.Attribute attribute : attributes) {
				if(attribute.getName().equals("Password")){
					if(attribute.getValue().equals(password)){
						return "loginSuccess";
					}
					else{
						System.out.println("The password is wrong");
						return "loginFail";
					}
				}
			}
		}
		return "loginFail";
	}
	
	/**
	 * 
	 * @return "loginFail" 		if the user does not exist, or the password is wrong, or the request is not valid.
	 * 		   "loginSuccess"	if the user name and password matches each other.
	 */
	private String fetchTopQuest() {
		// prepare a select with limit 20.
		SelectRequest selectRequest = new SelectRequest("select * from "+QuestInfoStorage+" limit 20");
		logger.info("The query is:"+selectRequest.toString());
		SelectResult result= simpleDB.select(selectRequest);
		
		java.util.Map<String, String> jsonMap = new HashMap<String, String>();
		List<Item> items = result.getItems();
		// Go through all the quests and put them into the resultObject.
		Integer i = new Integer(0);
		for (Item item : items) {
			List<com.amazonaws.services.simpledb.model.Attribute> attributes = item.getAttributes();
			java.util.Map<String, String> tempMap = new HashMap<String, String>();
			// Put all attribute into the tempJsonObject, which represent a quest.
			for (com.amazonaws.services.simpledb.model.Attribute attribute : attributes) {
				tempMap.put(attribute.getName(), attribute.getValue());
			}
			JSONObject tempJsonObject = new JSONObject(tempMap);
			jsonMap.put(i.toString(), tempJsonObject.toString());
			i++;
		}
		JSONObject jsonObject = new JSONObject(jsonMap);
		return jsonObject.toString();
	}
	
	/**
	 * clear all the messages in certain queueUrl
	 * @param queueUrl
	 */
	private void clearQueue(String queueUrl) {
		while (true) {
			try {
				int maxMessage = 10;
				ReceiveMessageResult receiveMessage = sqs.receiveMessage(new ReceiveMessageRequest().withMaxNumberOfMessages(maxMessage).withQueueUrl(queueUrl));
				for (Message msg : receiveMessage.getMessages()) {
					sqs.deleteMessage(new DeleteMessageRequest().withQueueUrl(queueUrl).withReceiptHandle(msg.getReceiptHandle()));
					logger.info("delete one message");
				}
				if (receiveMessage.getMessages().size() == 0){
					break;
				}
				sleep(500);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			} catch (Exception e) {
				// ignore and retry
			}
		}
	}
	
	/**
	 * check if all the domain that we need exists, if not, create new domain.
	 * We need 2 domain now: LoginInfo, QuestInfo
	 * @return
	 */
	private boolean DBCheck(){
		List<String> domains = simpleDB.listDomains().getDomainNames();
		int count = 0;
		for (String name : domains) {
			if(name.equals(LoginInfoStorage)){
				count++;
			}
			else if (name.equals(QuestInfoStorage)){
				count++;
			}
		}
		if (count == 2){
			domainExist = true;
			return true;
		}
		else{
			logger.warning("We miss some domain");
		}

		// If reach here, create the LoginInfo Domain.
		simpleDB.createDomain(new CreateDomainRequest(LoginInfoStorage));
		simpleDB.createDomain(new CreateDomainRequest(QuestInfoStorage));
		domainExist = true;
		return true;
	}

}

