/*
 * Copyright 2012 Amazon Technologies, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *    http://aws.amazon.com/apache2.0
 *
 * This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES
 * OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and
 * limitations under the License.
 */
package com.EECS441.questServer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.logging.Logger;


import com.EECS441.questServer.AWSResources;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.services.simpledb.AmazonSimpleDB;
import com.amazonaws.services.simpledb.AmazonSimpleDBClient;
import com.amazonaws.services.simpledb.model.CreateDomainRequest;
import com.amazonaws.services.simpledb.model.GetAttributesRequest;
import com.amazonaws.services.simpledb.model.GetAttributesResult;
import com.amazonaws.services.simpledb.model.PutAttributesRequest;
import com.amazonaws.services.simpledb.model.ReplaceableAttribute;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.util.json.JSONException;
import com.amazonaws.util.json.JSONObject;
import com.sun.xml.internal.xsom.impl.scd.Iterators.Map;



/**
 * The client reigister's job is to take request from SQS, look up the details in
 * SimpleDB, then return the reseult to client.
 * 
 * @author dichen
 */
public class ClientRegister extends Thread {
	static boolean domainExist = false;
	
	private final AmazonSQS sqs;
	private final AmazonSimpleDB simpleDB;
	private final ScheduledExecutorService executorService;
	private final ClasspathPropertiesFileCredentialsProvider provider = new ClasspathPropertiesFileCredentialsProvider();
	// the same as the message id.
	private final String registerProcessId;
	// The client+Send is the queue where client send stuff
	private String sendQueueUrl;
	// The client+Receive is the queue where client receive stuff
	private String receiveQueueUrl;
	private String userName;
	private String password;
	private final String LoginInfoStorage = "LoginInfo";
	
	private Logger logger = Logger.getLogger("ClientRegister");
	
	/**
	 * @param msg: msg.getBody() cannot be null
	 * 
	 * initializer:
	 * 1. setup the credential of AWS.
	 * 2. setup connection end point.
	 * 3. check the info storage database exist.
	 * 4. check the user name and user password
	 * 5. create connection queue using message ID as unique name.
	 * 
	 */
	public ClientRegister(Message msg) {
		// Setup the sqs
		sqs = new AmazonSQSClient(provider);
		sqs.setEndpoint(AWSResources.SQS_ENDPOINT);
		simpleDB = new AmazonSimpleDBClient(provider);
		// Check if the domain we need all exist.
		if (domainExist == false){
			DBCheck();
		}
		// set client name
		registerProcessId = msg.getMessageId();
		userName = null;
		password = null;
		try {
			JSONObject message = new JSONObject(msg.getBody());
			userName = (String) message.get("userName");
			password = (String) message.get("password");
			// create two queues for this client.
			// The client+Send is the queue where client send stuff
			receiveQueueUrl = sqs.createQueue(new CreateQueueRequest(registerProcessId+"Send")).getQueueUrl();
			// The client+Receive is the queue where client receive stuff
			sendQueueUrl = sqs.createQueue(new CreateQueueRequest(registerProcessId+"Receive")).getQueueUrl();
			clearQueue(receiveQueueUrl);
			clearQueue(sendQueueUrl);
		} catch (JSONException e) {
			e.printStackTrace();
		}

				
		executorService = new ScheduledThreadPoolExecutor(10);
	}

	@Override
	public void run() {		
		// get client name
		if (userName == null || password == null){
			exit();
			return;
		}
		if(userExist(userName)){
			java.util.Map<String,String> jsonMap = new HashMap<String,String>();
			jsonMap.put("registerStatus", "userAlreadyExist");
			sqs.sendMessage(new SendMessageRequest(sendQueueUrl, new JSONObject(jsonMap).toString()));;		}
		else{
			try{
				registerUser(userName,password);
				java.util.Map<String,String> jsonMap = new HashMap<String,String>();
				jsonMap.put("registerStatus", "registerSuccess");
				sqs.sendMessage(new SendMessageRequest(sendQueueUrl, new JSONObject(jsonMap).toString()));;
			} catch (Exception e) {
				java.util.Map<String,String> jsonMap = new HashMap<String,String>();
				jsonMap.put("registerStatus", "fail");
				sqs.sendMessage(new SendMessageRequest(sendQueueUrl, new JSONObject(jsonMap).toString()));;
				e.printStackTrace();
			} 
		}
		
	}
	
	// clear the queue and exit.
	private void exit() {
		return;
	}
	
	/**
	 * clear all the messages in certain queueUrl
	 * 
	 * @param queueUrl
	 */
	private void clearQueue(String queueUrl) {
		while (true) {
			try {
				int maxMessage = 10;
				ReceiveMessageResult receiveMessage = sqs.receiveMessage(new ReceiveMessageRequest().withMaxNumberOfMessages(maxMessage).withQueueUrl(receiveQueueUrl));
				for (Message msg : receiveMessage.getMessages()) {
					sqs.deleteMessage(new DeleteMessageRequest().withQueueUrl(receiveQueueUrl).withReceiptHandle(msg.getReceiptHandle()));
				}
				if (receiveMessage.getMessages().size() == 0){
					break;
				}
				sleep(500);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			} catch (Exception e) {
				// ignore and retry
			}
		}
	}
	
	

	
	/* return true 		if the user is already in the database.
	 * return false 	if the user is not exist in the database.
	 */
	private boolean userExist (String userName){
		GetAttributesResult result = simpleDB.getAttributes(new GetAttributesRequest(LoginInfoStorage, userName));
		if (result.getAttributes().size() == 0){
			return false;
		}
		else{
			return true;
		}
	}
	
	/* register the user login info.
	 * register the user's user info.
	 */
	private void registerUser(String userName, String password) {
		logger.info("Register request for user:"+userName+" password:"+password);
		List<ReplaceableAttribute> attributeList = new ArrayList<ReplaceableAttribute>();
		attributeList.add(new ReplaceableAttribute("Password", password, true));
		attributeList.add(new ReplaceableAttribute("UserName", userName, true));
		PutAttributesRequest insertRequest = new PutAttributesRequest(LoginInfoStorage, userName, attributeList);
		simpleDB.putAttributes(insertRequest);
	}
	
	
	
	/**
	 * check if all the domain that we need exists, if not, create new domain.
	 * @return
	 */
	private boolean DBCheck(){
		List<String> domains = simpleDB.listDomains().getDomainNames();
		for (String name : domains) {
			if(name.equals(LoginInfoStorage)){
				logger.info("domain LoginInfo exist");
				domainExist = true;
				return true;
			}
		}

		// If reach here, create the LoginInfo Domain.
		simpleDB.createDomain(new CreateDomainRequest(LoginInfoStorage));
		domainExist = true;
		return true;
	}
	
	
}


